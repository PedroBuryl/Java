package list1;

import java.util.Scanner;

public class Atividade3 {

	/*Write a program that prints on the screen the sum of the
	odd numbers between 0 and 30 and the multiplication of the
	even numbers between 0 and 30.*/

	public static void Class(){

		int num = 0, sum = 0, mult = 0;

		while (num <= 30) {
			if (num % 2 == 0) {
				sum = num + sum;
			}else{
				mult = num + mult;
			}
			num++;
		}

		System.out.println(sum);
		System.out.println("");
		System.out.println(mult*15);
	}

	public static void main(String[] args) {

		Class();
	}
}