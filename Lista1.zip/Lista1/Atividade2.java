package list1;

import java.util.Scanner;

public class Atividade2 {

	/*Create a NumberDegree Descending java class that contains
	a method that receives an integer and prints, in descending
	order, the number value up to 0*/

	public static void NumberDegree(){
		
		int num;
		Scanner scan = new Scanner(System.in);

		System.out.println("Type the number:");
		num = scan.nextInt();
		System.out.println("");

		while (num >= 0) {
			System.out.println(num);
			num--;
		}		
	}

	public static void main(String[] args) {

		NumberDegree();
	}
}