package list1;

import java.util.Scanner;

public class Atividade5 {

	/*Create a CompareNumber number java class that contains
	a method that receives two numbers and indicates whether
	they are the same or different. Show the biggest and the
	smallest (in this sequence)*/

	public static void CompareNumber(){

		Scanner scan = new Scanner(System.in);
		int num1, num2;

		System.out.println("Type the first number:");
		num1 = scan.nextInt();
		System.out.println("Type the second number:");
		num2 = scan.nextInt();

		if (num1 > num2) {
			System.out.println("The numbers are not the same");
			System.out.println("The biggest number is "+num1);
		}else if (num2 > num1) {
			System.out.println("The numbers are not the same");
			System.out.println("The smallest number is "+num2);
		}else{
			System.out.println("The number are the same");
		}
	}
	
	public static void main(String[] args) {

		CompareNumber();
	}
}