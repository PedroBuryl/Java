package list1;

import java.util.Scanner;

public class Atividade4 {

	/*Create a java class ExchangeNumber that contains a method
	that receives two NumA and NumB numbers, in that order, and
	print in reverse order, that is, if the data read are
	NumA = 5 and NumB = 9, for example, they must be printed
	in order NumA = 9 and NumB = 5*/

	public static void ExchangeNumber(){

		int numA, numB, aux/*auxiliar variable*/;
		Scanner scan = new Scanner(System.in);

		System.out.println("Type the num A:");
		numA = scan.nextInt();
		System.out.println("Type the num B:");
		numB = scan.nextInt();

		aux = numA;
		numA = numB;
		numB = aux;

		System.out.println("num A: "+numA);
		System.out.println("");
		System.out.println("num B: "+numB);
	}

	public static void main(String[] args) {

		ExchangeNumber();
	}
}