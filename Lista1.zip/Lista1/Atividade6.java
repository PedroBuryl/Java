package lista1;

import java.util.Scanner;

public class Atividade6 {

    /*(CHALLENGE) Create a MidStudent class that contains an
    attribute of type vector of integers with the name of notes.
    This class must have a method for adding grades to this
    vector (the values that can be added to the vector are
    integers between 0 and 100, otherwise it prints an error
    message and does not add) and another method that
    calculates a student's average and print that average.*/

    public static void StudentNote(){
        
        int notes[] = new int[3];
        Scanner scan = new Scanner(System.in);
        
        for (int i = 0; i < notes.length; i++) {
            System.out.println("Type the "+(i+1)+"ª note:");
            notes[i] = scan.nextInt();
            while (notes[i]<0 || notes[i]>100){
                System.out.println("Invalid number!!!!");
                System.out.println("");
                System.out.println("Enter a number from 0 - 100:");
                notes[i] = scan.nextInt();
            }
        }
        MidStudent(notes[0], notes[1], notes[2]);
    }

    public static void MidStudent(int note1, int note2, int note3){
        
        int average;
        
        average = (note1 + note2 + note3) / 3;
        
        System.out.println("The average student is "+average);
    }

    public static void main(String[] args) {
            
        StudentNote();
    }
}