package list1;

import java.util.Scanner;

public class Atividade1 {

	/*Create a Major Number java class that contains a method
	that takes two integers and prints the biggest one between
	them*/

	public static void MajorNumber(){

		Scanner scan = new Scanner(System.in); //scan object
		int num1, num2;

		System.out.println("Type the first number:");
		num1 = scan.nextInt();
		System.out.println("Type the second number:");
		num2 = scan.nextInt();

		if (num1 > num2) {
			System.out.println("The biggest number is "+num1);
		}else if (num2 > num1) {
			System.out.println("The smallest number is "+num2);
		}else{
			System.out.println("The number are the same");
		}
	}

	public static void main(String[] args) {
		
		MajorNumber();
	}
}